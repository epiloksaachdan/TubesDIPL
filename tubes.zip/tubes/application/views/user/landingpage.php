<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>

<div class="container">
	<div class="row">
		<div class="colwelcome">
			Welcome to E.Book !
		</div>
	</div>
</div>

<div class="container">
	<div class="row">
		
	</div>
</div>

<div class="container">
<div class="row">
		<div class="col">
			<div class="row">
				<div class="col">
					<P>Daftar akun</P>
				</div>
			</div>
		</div>
		<div class="col" id=login>
			<p>Sudah punya akun</p>
		</div>
	</div>
	<div class="row">
		<div class="col">
			<div class="row">
				<div class="col">
				<form class="form1" action="<?php echo base_url('index.php/Home/regbaca')?>">
					<button type="button" class="btn1 ">pembaca</button>
					</form>
					
				</div>
				<div class="col">
					<button type="button" class="btn1 ">pembaca</button>
				</div>
			</div>
		</div>
		<div class="col" id=login>
			<button type="button" class="btn1 ">Login</button>
		</div>
	</div>
	
</div>
	


  </body>
</html>

<style type="text/css">
	
	p {
		font-size:27px;
	}
	body{
		background:#4F646F;
	}
	.colwelcome{
		padding-top:50px;
		font-size:50px;
	}
	.col{
		padding-top:50px;
		
	}
	.btn1,.btn2{
		font-size:20px;
		background-color:#dee7e7;
		border-radius:20px;
		height:75px;
		width:200px;
		
	}


</style>